﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalculadora
{
    public partial class Form1 : Form
    {
        double numero1, numero2, resultado;  // globais


        public Form1()
        {
            InitializeComponent();
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            txtNum1.Text = "";
            txtNum2.Text = "";
            txtNum3.Text = "";

            //OU
            txtNum1.Clear();
            txtNum2.Clear();
            txtNum3.Clear();

            //OU

            txtNum1.Text = String.Empty;
            txtNum2.Text = String.Empty;
            txtNum3.Text = String.Empty;


            //ou

            txtNum1.Text = null;
            txtNum2.Text = null;
            txtNum3.Text = null;

            // volta para o numero 1 limpa resultado
            txtNum1.Focus();
            resultado = 0;

        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
           
             if (MessageBox.Show("Você deseja sair mesmo?",
               "Saída", MessageBoxButtons.YesNo, 
               MessageBoxIcon.Question)==
               DialogResult.Yes)
            {
                Close();
            }
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            

            resultado = numero1 + numero2;
            txtNum3.Text = resultado.ToString();

        }



        private void BtnSub_Click(object sender, EventArgs e)
        {
            //errorProvider1.SetError(txtNum1, "");
            //errorProvider2.SetError(txtNum2, "");

           
                resultado = numero1 - numero2;
                txtNum3.Text = resultado.ToString();
                      
        }

        private void txtNum1_Validated(object sender, EventArgs e)
        {
           

            if (!Double.TryParse(txtNum1.Text, out numero1))
            {
                MessageBox.Show("número inválido!");
                txtNum1.Focus();
            }
        }

        private void txtNum2_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNum2.Text, out numero2))
            {
                MessageBox.Show("número inválido!");
                txtNum2.Focus();
            }
           








            //if (!Double.TryParse(txtNum2.Text, out numero2))
            //{
            //    errorProvider2.SetError(txtNum2, "Numero 2 invalido");
            //    // MessageBox.Show("Número 2 inválido!");
            //    //  txtNum2.Focus();
            //}
        }

        private void txtNum1_Validating(object sender, CancelEventArgs e)
        {
            
        }

        private void btnLimpar_Enter(object sender, EventArgs e)
        {

        }

        private void txtNum1_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtNum1_ReadOnlyChanged(object sender, EventArgs e)
        {

        }

        private void txtNum1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void txtNum1_MouseEnter(object sender, EventArgs e)
        {

        }

        private void lblNumero1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
//      }

        private void BtnMult_Click(object sender, EventArgs e)
        {
            errorProvider1.SetError(txtNum1, "");
            errorProvider2.SetError(txtNum2, "");

            if (double.TryParse(txtNum1.Text, out numero1) &&
          double.TryParse(txtNum2.Text, out numero2))
            {
                resultado = numero1 * numero2;
                txtNum3.Text = resultado.ToString();
            }
            else
                MessageBox.Show("Números inválidos!!");
        }


        private void BtnDiv_Click(object sender, EventArgs e)
        {
            if (numero2 == 0)
            {
                MessageBox.Show("não pode dividir por zero!!!", "Erro",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtNum2.Focus();
            }
            else
            {
                resultado = numero1 / numero2;
                txtNum3.Text = resultado.ToString();
            }
        }

    } // FECHA PARTIAL CLASS
}// FECHA NAMESPACE

